package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.cg.entity.Products;
import com.cg.service.ProductService;

@RestController
@CrossOrigin("http://localhost:4200")
public class ProductsController {

	@Autowired
	private ProductService productService;
	
	@RequestMapping(value="/addproducts/{productId}/{productName}/{productQuantity}/{price}/{categoryName}/{brand}/{merchantId}",headers="Accept=application/json",method = RequestMethod.GET) 
	public Products addProducts(@PathVariable int productId,@PathVariable String productName,@PathVariable int productQuantity,@PathVariable float price,@PathVariable String categoryName,@PathVariable String brand,@PathVariable int merchantId) {
		
		Products products = new Products();
		products.setProductId(productId);
		products.setProductName(productName);
		products.setProductQuantity(productQuantity);
		products.setPrice(price);
		products.setCategoryName(categoryName);
		products.setBrand(brand);
	    products.setMerchantId(merchantId);
		return productService.addNewProduct(products);
		
	}
	@RequestMapping(value="/removeproducts/{productId}",headers="Accept=application/json",method = RequestMethod.DELETE) 
	public void deleteProduct(@PathVariable int productId) {
		
		productService.removeProduct(productId);
	}
		@RequestMapping(value="/displayallproducts",headers="Accept=application/json",method = RequestMethod.GET)
	public List<Products> displayAll(){
		return productService.displayListOfProducts();
		
	}
}
