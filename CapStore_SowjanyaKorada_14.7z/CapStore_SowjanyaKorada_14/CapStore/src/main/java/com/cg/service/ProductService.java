package com.cg.service;

import java.util.List;

import com.cg.entity.Products;

public interface ProductService {

	public Products addNewProduct(Products product);
	public void removeProduct(int productId);
  
	List<Products> displayListOfProducts();
}
