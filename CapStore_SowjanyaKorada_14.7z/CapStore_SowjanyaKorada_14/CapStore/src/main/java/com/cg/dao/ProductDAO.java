package com.cg.dao;

import java.util.List;

import com.cg.entity.Products;

public interface ProductDAO {

	public Products addNewProduct(Products product);
	public void removeProduct(int productId);
	List<Products> displayListOfProducts();
}
