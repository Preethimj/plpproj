package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entity.Products;
@Repository
public class ProductDAOImpl implements ProductDAO {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public Products addNewProduct(Products product) {
	
	 entityManager.persist(product);
	 entityManager.flush();
	 return product;
	
	}

	@Override
	public void removeProduct(int productId) {
	
		Products p=entityManager.find(Products.class, productId);
		
		 entityManager.remove(p);
		
			}
		
	


	@Override
	public List<Products> displayListOfProducts() {
		
		TypedQuery<Products> query=entityManager.createQuery("select product from Products product",Products.class);
		return query.getResultList();
	}

}
