export interface Product{
    productId : number;
    productName : String;
    productQuantity : number;
    price : number;
    categoryName : String;
    brand : String;
    merchantId : number;
}