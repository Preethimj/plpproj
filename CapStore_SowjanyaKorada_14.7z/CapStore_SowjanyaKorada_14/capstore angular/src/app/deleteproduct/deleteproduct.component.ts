import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';

import { ProductService } from '../product.service';

import { Product } from '../product/product';



@Component({
  selector: 'app-deleteproduct',
  templateUrl: './deleteproduct.component.html',
  styleUrls: ['./deleteproduct.component.css']
})
export class DeleteproductComponent implements OnInit {
product : Observable<Product[]>
  constructor(private service : ProductService) { }

  ngOnInit() {
  
  }
 
  delete(productId : number){
    this.service.deleteProduct(productId).subscribe(
      data => {
        console.log(data);
        alert("product deleted");
      }
    )
  }
}
