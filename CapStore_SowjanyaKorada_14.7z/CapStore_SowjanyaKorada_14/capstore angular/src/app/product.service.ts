import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Product } from './product/product';
import { FetchProducts } from './fetchallproducts/fetchproducts';





@Injectable({
  providedIn: 'root'
})
export class ProductService {
 url: string;
 url1 :string;
 url2 :string;


  constructor(private http : HttpClient) {
  this.url=  'http://localhost:8089/addproducts';
  this.url1= 'http://localhost:8089/displayallproducts';
  this.url2= 'http://localhost:8089/removeproducts';
  }
  addProducts(productId:number,productName:string,productQuantity : number,price : number,categoryName : string,
    brand : string,merchantId : number) : Observable<any>
  {
  return this.http.get(`${this.url}/${productId}/${productName}/${productQuantity}/${price}/${categoryName}/${brand}/${merchantId}`,{responseType :'text'});
 
  }
  getAllProducts():Observable<FetchProducts []>{
    return this.http.get<FetchProducts []>(this.url1);
  }
  deleteProduct(productId:number):Observable<any>{
return this.http.delete(`${this.url2}/${productId}`, { responseType: 'text'});  
}
 
}
