import { Component, OnInit } from '@angular/core';
import { FetchProducts } from './fetchproducts';
import { ProductService } from '../product.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-fetchallproducts',
  templateUrl: './fetchallproducts.component.html',
  styleUrls: ['./fetchallproducts.component.css']
})
export class FetchallproductsComponent implements OnInit {
  products : FetchProducts[];
 isget:boolean;
  constructor(private service : ProductService) { }

  ngOnInit() {
    
    this.service.getAllProducts().subscribe((getAllProducts)=>this.products=getAllProducts);
  
  }

}
