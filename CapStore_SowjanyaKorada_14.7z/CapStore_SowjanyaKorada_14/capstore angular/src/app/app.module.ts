import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { ProductComponent } from './product/product.component';
import { HttpClientModule} from '@angular/common/http';
import { DeleteproductComponent } from './deleteproduct/deleteproduct.component';
import { FetchallproductsComponent } from './fetchallproducts/fetchallproducts.component';
import { Route,RouterModule } from '@angular/router';
const routes :Route[] = [
  {
    path :'add',
    component :ProductComponent
  },
  {
    path : 'delete',
    component : DeleteproductComponent
  },
  {
    path : 'fetch',
    component : FetchallproductsComponent
  },
];
@NgModule({
  declarations: [
    AppComponent,
    ProductComponent,
    DeleteproductComponent,
    FetchallproductsComponent
  ],
  imports: [
    BrowserModule,FormsModule, HttpClientModule,RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
