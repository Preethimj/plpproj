import { Component, OnInit } from '@angular/core';
import { Product } from './product';
import { ProductService } from '../product.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
products : Product[];
isUpdate : boolean=false;
productId : number;
    productName : string;
    productQuantity : number;
    price : number;
    categoryName : string;
    brand : string;
    merchantId : number;

statusmessage :String;
  constructor(private service : ProductService) { }
  product: Product[];

  ngOnInit() {
  
  }

  onSubmit() {
   
    this.service.addProducts(this.productId,this.productName,this.productQuantity,this.price,this.categoryName,this.brand,this.merchantId)
    .subscribe();
  alert("product added to list");
  }

}
